const Store= require('./store');
const StoreItem= require('./store-item');



class Customer {
    constructor(name) {
        this.name= name;
        this.money= 0;
        this.purchases= [];
    }
    addFunds(funds) {
        this.money += funds;
    }

    withdrawFunds(withdraw) {
        if (this.money > withdraw) {
             this.money -= withdraw;
        } else {
            throw new Error("There's insufficent funds to complete transaction");
        }
    }
}




module.exports= Customer;