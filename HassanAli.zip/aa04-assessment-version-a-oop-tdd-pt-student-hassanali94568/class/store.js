const StoreItem= require('./store-item');




class Store {
    constructor() {
        this.items= []
    }
    addItem(item){
        if (item.isValid() && item instanceof StoreItem) {
            this.items.push(item)
        } else {
            throw new Error("Invalid item:", item);        
        }
    }
    getStoreItemPrices() {
        return this.items.map(item => `${item.name}: $${item.price}`)
    }
    
}




module.exports= Store;
